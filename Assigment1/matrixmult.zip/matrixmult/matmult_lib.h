#ifndef __MATMULT_LIB_H
#define __MATMULT_LIB_H
void matmult_lib(int m, int n, int k,double** A, double** B, double** C);
#endif  